MON RPG 2D - INVENTAIRE

1. Ouvre ce dossier dans Visual Studio Code.
2. Ouvre le terminal dans le dossier.
3. Installe Arcade :
   py -m pip install -r requirements.txt
4. Lance le jeu :
   py main.py

IMAGE DE L'ARME
Le jeu fonctionne déjà sans image.
Plus tard, place ton image ici :
weapons/sword.png

Tu peux ensuite modifier le nom, les statistiques et les autres armes
directement dans ITEMS dans main.py.
